from .version import Version
from .deprecation import deprecated
from .details import API, CURRENT, DESCRIPTION
from .errors import VersionError
