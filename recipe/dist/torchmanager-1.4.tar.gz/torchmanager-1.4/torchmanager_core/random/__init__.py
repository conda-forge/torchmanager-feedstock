from .random import rand, rand_like, randbool, randbool_like, randint, randint_like, randn, randn_like, randperm
from .seed import freeze_seed, unfreeze_seed